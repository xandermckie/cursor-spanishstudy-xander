/* Estudio Abroad — Home Page */

function HomePage() {
  const { dark } = useTheme();
  const C = TOKENS.colors;
  const [celebShow, setCelebShow] = React.useState(false);

  return (
    <PageContent>
      {/* Hero greeting with Pez */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 16, marginBottom: 28,
        flexWrap: 'wrap',
      }}>
        <PezAnimated size={64} expression="happy" speech="¡Hola, Xander! Ready to learn?" />
        <div style={{ flex: 1, minWidth: 200 }}>
          <h1 style={{
            fontSize: 28, fontWeight: 800, color: dark ? C.darkText : C.text,
            fontFamily: TOKENS.font.heading, margin: 0, letterSpacing: '-0.02em',
          }}>Buenos días</h1>
          <p style={{
            fontSize: 15, color: dark ? C.darkTextSecondary : C.textSecondary,
            margin: '4px 0 0', fontFamily: TOKENS.font.body,
          }}>Keep up the momentum — you're doing great.</p>
        </div>
      </div>

      {/* Stats row */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
        gap: 12, marginBottom: 28,
      }}>
        <StatCard icon="🔥" value="7" label="Day streak" color={C.secondary} />
        <StatCard icon="⭐" value="120" label="Total XP" color={C.primary} />
        <StatCard icon="📝" value="48" label="Words learned" color={C.teal} />
        <StatCard icon="💪" value="82%" label="Accuracy" color={C.green} />
      </div>

      {/* XP Progress */}
      <Card style={{ marginBottom: 20, padding: '18px 22px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <span style={{ fontSize: 14, fontWeight: 700, fontFamily: TOKENS.font.heading, color: dark ? C.darkText : C.text }}>Daily Progress</span>
          <StreakBadge days={7} />
        </div>
        <XPBar current={120} max={200} level={3} />
        <p style={{ fontSize: 12, color: C.textMuted, margin: '8px 0 0' }}>80 XP more to reach Level 4</p>
      </Card>

      {/* Palabra del día */}
      <SectionHeader title="Palabra del día" subtitle="Today's word to learn" />
      <Card style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, flexWrap: 'wrap' }}>
          <div style={{
            width: 56, height: 56, borderRadius: TOKENS.radius.lg,
            background: `linear-gradient(135deg, ${C.primary}, ${C.secondary})`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 24, color: '#fff', fontWeight: 800, flexShrink: 0,
            fontFamily: TOKENS.font.heading,
          }}>A</div>
          <div style={{ flex: 1 }}>
            <h3 style={{
              fontSize: 26, fontWeight: 800, color: dark ? C.darkText : C.text,
              fontFamily: TOKENS.font.heading, margin: 0,
            }}>acogedor</h3>
            <p style={{ fontSize: 13, color: C.textMuted, margin: '2px 0 6px', fontFamily: TOKENS.font.body }}>
              /a·ko·xe·ˈðor/
            </p>
            <div onClick={() => {
              const el = document.getElementById('wod-meaning');
              if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none';
            }} style={{
              cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6,
              background: dark ? C.darkSurface2 : C.primaryLight,
              padding: '6px 14px', borderRadius: TOKENS.radius.full,
              fontSize: 13, fontWeight: 600, color: C.primary, marginBottom: 8,
            }}>
              <span style={{ fontSize: 16 }}>👁</span> Tap to reveal meaning
            </div>
            <div id="wod-meaning" style={{ display: 'none' }}>
              <p style={{ fontSize: 15, color: C.teal, fontWeight: 600, margin: '0 0 8px' }}>
                cozy, welcoming, warm (adjective)
              </p>
            </div>
          </div>
        </div>
        <div style={{
          marginTop: 16, padding: '14px 18px',
          background: dark ? C.darkSurface2 : '#FFF8F5',
          borderRadius: TOKENS.radius.md,
          borderLeft: `3px solid ${C.primary}`,
        }}>
          <p style={{ fontSize: 13, color: C.textMuted, margin: '0 0 4px', fontWeight: 600 }}>Ejemplo</p>
          <p style={{ fontSize: 16, fontWeight: 600, color: dark ? C.darkText : C.text, margin: '0 0 4px', fontFamily: TOKENS.font.body }}>
            Este café es muy acogedor, me encanta estudiar aquí.
          </p>
          <p style={{ fontSize: 14, color: C.teal, fontStyle: 'italic', margin: 0, cursor: 'pointer' }}
            onClick={e => { e.target.style.opacity = e.target.style.opacity === '1' ? '0.3' : '1'; }}
            title="Click to toggle"
          >
            This café is very cozy, I love studying here.
          </p>
        </div>
      </Card>

      {/* Frase del día */}
      <SectionHeader title="Frase del día" subtitle="Practice this sentence today" />
      <RevealCard
        spanish="Me gustaría una mesa cerca de la ventana, por favor."
        english="I'd like a table near the window, please."
        style={{ marginBottom: 24 }}
      />

      {/* Frase corta */}
      <SectionHeader title="Frase corta" subtitle="Quick phrase for Barcelona" />
      <RevealCard
        spanish="¿Dónde está la parada de metro más cercana?"
        english="Where is the nearest metro stop?"
        style={{ marginBottom: 24 }}
      />

      {/* Weak Words */}
      <SectionHeader title="Palabras débiles" subtitle="Words you've missed most in flashcards" />
      <Card style={{ padding: 0, overflow: 'hidden', marginBottom: 24 }}>
        {[
          { es: 'conseguir', en: 'to get, to achieve', misses: 5 },
          { es: 'desarrollar', en: 'to develop', misses: 4 },
          { es: 'averiguar', en: 'to find out', misses: 3 },
          { es: 'madrugada', en: 'early morning / dawn', misses: 3 },
          { es: 'disponible', en: 'available', misses: 2 },
        ].map((w, i) => (
          <div key={i} onClick={() => {
            const el = document.getElementById(`weak-en-${i}`);
            if (el) el.style.display = el.style.display === 'none' ? 'flex' : 'none';
          }} style={{
            display: 'flex', alignItems: 'center', gap: 14,
            padding: '14px 20px',
            borderBottom: i < 4 ? `1px solid ${dark ? C.darkBorder : C.borderLight}` : 'none',
            cursor: 'pointer',
            transition: 'background 0.15s ease',
          }}
            onMouseEnter={e => e.currentTarget.style.background = dark ? C.darkSurface2 : '#FAFAFA'}
            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
          >
            <div style={{
              width: 28, height: 28, borderRadius: TOKENS.radius.full,
              background: C.red + '14', color: C.red,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 12, fontWeight: 800, flexShrink: 0,
            }}>{w.misses}</div>
            <div style={{ flex: 1 }}>
              <span style={{ fontSize: 15, fontWeight: 600, color: dark ? C.darkText : C.text }}>{w.es}</span>
              <div id={`weak-en-${i}`} style={{
                display: 'none', alignItems: 'center', gap: 6, marginTop: 4,
              }}>
                <span style={{ fontSize: 13, color: C.teal, fontStyle: 'italic' }}>{w.en}</span>
              </div>
            </div>
            <span style={{ fontSize: 11, color: C.textMuted }}>
              {w.misses} miss{w.misses !== 1 ? 'es' : ''}
            </span>
          </div>
        ))}
      </Card>

      {/* Quick Actions */}
      <SectionHeader title="Continue learning" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12 }}>
        {[
          { icon: '📖', title: 'Lector', desc: 'Fog-reveal reading', page: 'reader', color: C.teal },
          { icon: '🃏', title: 'Tarjetas', desc: 'Flashcard practice', page: 'vocab', color: C.primary },
          { icon: '💬', title: 'Frases', desc: 'Build your phrasebook', page: 'phrasebook', color: C.secondary },
          { icon: '✈️', title: 'Viajes', desc: 'Explore Barcelona', page: 'travel', color: '#8B5CF6' },
        ].map((a, i) => (
          <Card key={i} hover onClick={() => window.__navigate && window.__navigate(a.page)} style={{ padding: '20px', cursor: 'pointer' }}>
            <div style={{
              width: 44, height: 44, borderRadius: TOKENS.radius.md,
              background: a.color + '14', display: 'flex', alignItems: 'center',
              justifyContent: 'center', fontSize: 22, marginBottom: 12,
            }}>{a.icon}</div>
            <h3 style={{ fontSize: 16, fontWeight: 700, color: dark ? C.darkText : C.text, margin: '0 0 4px', fontFamily: TOKENS.font.heading }}>{a.title}</h3>
            <p style={{ fontSize: 13, color: dark ? C.darkTextSecondary : C.textSecondary, margin: 0 }}>{a.desc}</p>
          </Card>
        ))}
      </div>

      <CelebrationOverlay show={celebShow} onDone={() => setCelebShow(false)} />
    </PageContent>
  );
}

window.HomePage = HomePage;
