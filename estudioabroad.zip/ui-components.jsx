/* Estudio Abroad — Shared UI Components */

/* ── Design Tokens ── */
const TOKENS = {
  colors: {
    primary: '#FF6B35',
    primaryDark: '#E55A2B',
    primaryLight: '#FFF0EB',
    secondary: '#FFB627',
    secondaryLight: '#FFF8E7',
    teal: '#2EC4B6',
    tealLight: '#E8FAF8',
    red: '#E63946',
    green: '#22C55E',
    greenLight: '#ECFDF5',
    bg: '#FAFAF8',
    surface: '#FFFFFF',
    surfaceHover: '#F9FAFB',
    text: '#1A1A2E',
    textSecondary: '#6B7280',
    textMuted: '#9CA3AF',
    border: '#E5E7EB',
    borderLight: '#F3F4F6',
    shadow: '0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04)',
    shadowMd: '0 4px 12px rgba(0,0,0,0.08)',
    shadowLg: '0 8px 24px rgba(0,0,0,0.1)',
    // Dark mode
    darkBg: '#0F1117',
    darkSurface: '#1A1D28',
    darkSurface2: '#242736',
    darkText: '#F0F0F5',
    darkTextSecondary: '#9CA3AF',
    darkBorder: '#2D3042',
  },
  radius: { sm: 8, md: 12, lg: 16, xl: 20, full: 9999 },
  font: {
    heading: "'DM Sans', 'Plus Jakarta Sans', system-ui, sans-serif",
    body: "'Plus Jakarta Sans', 'DM Sans', system-ui, sans-serif",
  },
};

/* ── Theme Context ── */
const ThemeContext = React.createContext({ dark: false, toggle: () => {} });

function useTheme() {
  return React.useContext(ThemeContext);
}

function t(dark, light, darkVal) {
  return dark ? darkVal : light;
}

/* ── Navbar ── */
function Navbar({ currentPage, onNavigate }) {
  const { dark, toggle } = useTheme();
  const C = TOKENS.colors;
  const bg = dark ? C.darkSurface : C.surface;
  const border = dark ? C.darkBorder : C.border;
  const text = dark ? C.darkText : C.text;
  const muted = dark ? C.darkTextSecondary : C.textSecondary;

  const links = [
    { key: 'home', label: 'Inicio', icon: '🏠' },
    { key: 'reader', label: 'Lector', icon: '📖' },
    { key: 'vocab', label: 'Tarjetas', icon: '🃏' },
    { key: 'phrasebook', label: 'Frases', icon: '💬' },
    { key: 'travel', label: 'Viajes', icon: '✈️' },
    { key: 'news', label: 'Noticias', icon: '📰' },
    { key: 'history', label: 'Historia', icon: '🏛️' },
    { key: 'resources', label: 'Recursos', icon: '📚' },
  ];

  const [mobileOpen, setMobileOpen] = React.useState(false);

  return (
    <nav style={{
      background: bg,
      borderBottom: `1px solid ${border}`,
      position: 'sticky',
      top: 0,
      zIndex: 100,
      padding: '0 24px',
    }}>
      <div style={{
        maxWidth: 1120,
        margin: '0 auto',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: 60,
      }}>
        {/* Logo */}
        <button onClick={() => onNavigate('home')} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: 'none', border: 'none', cursor: 'pointer', padding: 0,
        }}>
          <Pez size={36} expression="happy" />
          <span style={{
            fontFamily: TOKENS.font.heading,
            fontSize: 18,
            fontWeight: 800,
            color: C.primary,
            letterSpacing: '-0.02em',
          }}>Estudio Abroad</span>
        </button>

        {/* Desktop links */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 4,
        }} className="nav-desktop">
          {links.map(l => (
            <button
              key={l.key}
              onClick={() => onNavigate(l.key)}
              style={{
                background: currentPage === l.key ? C.primaryLight : 'transparent',
                color: currentPage === l.key ? C.primary : muted,
                border: 'none',
                borderRadius: TOKENS.radius.md,
                padding: '8px 14px',
                fontSize: 14,
                fontWeight: currentPage === l.key ? 700 : 500,
                fontFamily: TOKENS.font.body,
                cursor: 'pointer',
                transition: 'all 0.15s ease',
              }}
              onMouseEnter={e => { if (currentPage !== l.key) { e.target.style.background = dark ? C.darkSurface2 : '#F3F4F6'; e.target.style.color = text; } }}
              onMouseLeave={e => { if (currentPage !== l.key) { e.target.style.background = 'transparent'; e.target.style.color = muted; } }}
            >
              {l.label}
            </button>
          ))}
          {/* Dark mode toggle */}
          <button onClick={toggle} style={{
            background: dark ? C.darkSurface2 : '#F3F4F6',
            border: 'none',
            borderRadius: TOKENS.radius.full,
            width: 36, height: 36,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer',
            fontSize: 16,
            marginLeft: 8,
          }}>
            {dark ? '☀️' : '🌙'}
          </button>
        </div>

        {/* Mobile hamburger */}
        <button className="nav-mobile-toggle" onClick={() => setMobileOpen(!mobileOpen)} style={{
          background: 'none', border: 'none', fontSize: 24, cursor: 'pointer',
          color: text, display: 'none',
        }}>
          {mobileOpen ? '✕' : '☰'}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="nav-mobile-menu" style={{
          background: bg, borderTop: `1px solid ${border}`,
          padding: '12px 0', display: 'none',
        }}>
          {links.map(l => (
            <button key={l.key} onClick={() => { onNavigate(l.key); setMobileOpen(false); }}
              style={{
                display: 'block', width: '100%', textAlign: 'left',
                background: currentPage === l.key ? C.primaryLight : 'transparent',
                color: currentPage === l.key ? C.primary : text,
                border: 'none', padding: '12px 24px',
                fontSize: 15, fontWeight: currentPage === l.key ? 700 : 500,
                fontFamily: TOKENS.font.body, cursor: 'pointer',
              }}>
              {l.icon} {l.label}
            </button>
          ))}
          <button onClick={() => { toggle(); setMobileOpen(false); }} style={{
            display: 'block', width: '100%', textAlign: 'left',
            background: 'transparent', color: text,
            border: 'none', padding: '12px 24px',
            fontSize: 15, fontFamily: TOKENS.font.body, cursor: 'pointer',
          }}>
            {dark ? '☀️ Modo claro' : '🌙 Modo oscuro'}
          </button>
        </div>
      )}
    </nav>
  );
}

/* ── Card ── */
function Card({ children, style = {}, onClick, hover = false, className = '' }) {
  const { dark } = useTheme();
  const C = TOKENS.colors;
  const ref = React.useRef(null);
  return (
    <div
      ref={ref}
      className={className}
      onClick={onClick}
      style={{
        background: dark ? C.darkSurface : C.surface,
        border: `1px solid ${dark ? C.darkBorder : C.border}`,
        borderRadius: TOKENS.radius.lg,
        padding: 24,
        boxShadow: C.shadow,
        transition: 'all 0.2s ease',
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      }}
      onMouseEnter={e => { if (hover || onClick) { e.currentTarget.style.boxShadow = C.shadowMd; e.currentTarget.style.transform = 'translateY(-2px)'; } }}
      onMouseLeave={e => { if (hover || onClick) { e.currentTarget.style.boxShadow = C.shadow; e.currentTarget.style.transform = 'none'; } }}
    >
      {children}
    </div>
  );
}

/* ── Badge ── */
function Badge({ children, color = 'primary', style = {} }) {
  const C = TOKENS.colors;
  const colorMap = {
    primary: { bg: C.primaryLight, text: C.primary },
    teal: { bg: C.tealLight, text: C.teal },
    secondary: { bg: C.secondaryLight, text: '#B8860B' },
    green: { bg: C.greenLight, text: '#16A34A' },
    red: { bg: '#FEF2F2', text: C.red },
  };
  const c = colorMap[color] || colorMap.primary;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center',
      background: c.bg, color: c.text,
      fontSize: 12, fontWeight: 700, fontFamily: TOKENS.font.body,
      padding: '4px 10px', borderRadius: TOKENS.radius.full,
      letterSpacing: '0.02em',
      ...style,
    }}>{children}</span>
  );
}

/* ── Button ── */
function Btn({ children, variant = 'primary', size = 'md', onClick, style = {}, disabled = false }) {
  const C = TOKENS.colors;
  const { dark } = useTheme();
  const sizes = {
    sm: { padding: '8px 16px', fontSize: 13 },
    md: { padding: '10px 20px', fontSize: 14 },
    lg: { padding: '14px 28px', fontSize: 16 },
  };
  const variants = {
    primary: { bg: C.primary, color: '#fff', border: 'none', hoverBg: C.primaryDark },
    secondary: { bg: dark ? C.darkSurface2 : '#F3F4F6', color: dark ? C.darkText : C.text, border: `1px solid ${dark ? C.darkBorder : C.border}`, hoverBg: dark ? C.darkBorder : '#E5E7EB' },
    ghost: { bg: 'transparent', color: dark ? C.darkText : C.text, border: 'none', hoverBg: dark ? C.darkSurface2 : '#F3F4F6' },
    success: { bg: C.green, color: '#fff', border: 'none', hoverBg: '#16A34A' },
    danger: { bg: '#FEF2F2', color: C.red, border: `1px solid #FECACA`, hoverBg: '#FEE2E2' },
  };
  const v = variants[variant] || variants.primary;
  const sz = sizes[size] || sizes.md;
  return (
    <button onClick={onClick} disabled={disabled} style={{
      ...sz, background: v.bg, color: v.color, border: v.border || 'none',
      borderRadius: TOKENS.radius.md, fontWeight: 600, fontFamily: TOKENS.font.body,
      cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1,
      transition: 'all 0.15s ease', letterSpacing: '-0.01em', ...style,
    }}
      onMouseEnter={e => { if (!disabled) e.target.style.background = v.hoverBg; }}
      onMouseLeave={e => { if (!disabled) e.target.style.background = v.bg; }}
    >{children}</button>
  );
}

/* ── XP / Streak / Progress ── */
function XPBar({ current = 120, max = 200, level = 3 }) {
  const C = TOKENS.colors;
  const { dark } = useTheme();
  const pct = Math.min((current / max) * 100, 100);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <Badge color="secondary" style={{ fontWeight: 800, fontSize: 11 }}>Nivel {level}</Badge>
      <div style={{
        flex: 1, height: 10, background: dark ? C.darkSurface2 : '#F3F4F6',
        borderRadius: TOKENS.radius.full, overflow: 'hidden',
      }}>
        <div style={{
          width: `${pct}%`, height: '100%',
          background: `linear-gradient(90deg, ${C.secondary}, ${C.primary})`,
          borderRadius: TOKENS.radius.full,
          transition: 'width 0.5s ease',
        }} />
      </div>
      <span style={{ fontSize: 12, fontWeight: 700, color: C.primary, fontFamily: TOKENS.font.body }}>
        {current}/{max} XP
      </span>
    </div>
  );
}

function StreakBadge({ days = 7 }) {
  const C = TOKENS.colors;
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      background: C.secondaryLight, padding: '6px 14px',
      borderRadius: TOKENS.radius.full, fontFamily: TOKENS.font.body,
    }}>
      <span style={{ fontSize: 18 }}>🔥</span>
      <span style={{ fontWeight: 800, fontSize: 14, color: '#B8860B' }}>{days} días</span>
    </div>
  );
}

function StatCard({ icon, value, label, color = '#FF6B35' }) {
  const { dark } = useTheme();
  const C = TOKENS.colors;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 14,
      background: dark ? C.darkSurface : C.surface,
      border: `1px solid ${dark ? C.darkBorder : C.border}`,
      borderRadius: TOKENS.radius.lg,
      padding: '16px 20px',
      boxShadow: C.shadow,
    }}>
      <div style={{
        width: 44, height: 44, borderRadius: TOKENS.radius.md,
        background: color + '14', display: 'flex', alignItems: 'center',
        justifyContent: 'center', fontSize: 22,
      }}>{icon}</div>
      <div>
        <div style={{ fontSize: 22, fontWeight: 800, color: dark ? C.darkText : C.text, fontFamily: TOKENS.font.heading, lineHeight: 1 }}>{value}</div>
        <div style={{ fontSize: 12, color: dark ? C.darkTextSecondary : C.textSecondary, fontFamily: TOKENS.font.body, marginTop: 2 }}>{label}</div>
      </div>
    </div>
  );
}

/* ── Click-to-reveal (fun version) ── */
function RevealCard({ spanish, english, style = {} }) {
  const [open, setOpen] = React.useState(false);
  const { dark } = useTheme();
  const C = TOKENS.colors;
  return (
    <div onClick={() => setOpen(!open)} style={{
      padding: '16px 20px', cursor: 'pointer',
      background: open ? (dark ? C.darkSurface2 : C.primaryLight) : (dark ? C.darkSurface : C.surface),
      border: `1px solid ${open ? C.primary + '40' : (dark ? C.darkBorder : C.border)}`,
      borderRadius: TOKENS.radius.md,
      transition: 'all 0.25s ease',
      ...style,
    }}>
      <div style={{
        fontSize: 17, fontWeight: 600, color: dark ? C.darkText : C.text,
        fontFamily: TOKENS.font.body,
      }}>{spanish}</div>
      <div style={{
        overflow: 'hidden', transition: 'all 0.3s ease',
        maxHeight: open ? 100 : 0, opacity: open ? 1 : 0,
        marginTop: open ? 8 : 0,
      }}>
        <div style={{
          fontSize: 15, color: C.teal, fontStyle: 'italic',
          fontFamily: TOKENS.font.body,
        }}>{english}</div>
      </div>
      {!open && (
        <div style={{
          fontSize: 11, color: C.textMuted, marginTop: 4,
          fontFamily: TOKENS.font.body,
        }}>Toca para ver en inglés</div>
      )}
    </div>
  );
}

/* ── Section Header ── */
function SectionHeader({ title, subtitle, action, actionLabel, onAction }) {
  const { dark } = useTheme();
  const C = TOKENS.colors;
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 16, flexWrap: 'wrap', gap: 8 }}>
      <div>
        <h2 style={{
          fontSize: 22, fontWeight: 800, color: dark ? C.darkText : C.text,
          fontFamily: TOKENS.font.heading, margin: 0, letterSpacing: '-0.02em',
        }}>{title}</h2>
        {subtitle && <p style={{
          fontSize: 14, color: dark ? C.darkTextSecondary : C.textSecondary,
          fontFamily: TOKENS.font.body, margin: '4px 0 0',
        }}>{subtitle}</p>}
      </div>
      {actionLabel && <Btn variant="ghost" size="sm" onClick={onAction}>{actionLabel}</Btn>}
    </div>
  );
}

/* ── Footer ── */
function Footer() {
  const { dark } = useTheme();
  const C = TOKENS.colors;
  return (
    <footer style={{
      borderTop: `1px solid ${dark ? C.darkBorder : C.border}`,
      padding: '24px 24px 32px',
      textAlign: 'center',
      background: dark ? C.darkBg : C.bg,
    }}>
      <div style={{
        maxWidth: 1120, margin: '0 auto',
        fontFamily: TOKENS.font.body,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 8 }}>
          <Pez size={28} expression="wink" />
          <span style={{ fontSize: 14, fontWeight: 700, color: C.primary }}>Estudio Abroad</span>
        </div>
        <p style={{ fontSize: 13, color: dark ? C.darkTextSecondary : C.textSecondary, margin: '0 0 4px' }}>
          Estudio de español en Barcelona
        </p>
        <p style={{ fontSize: 12, color: dark ? C.darkTextSecondary : C.textMuted, margin: 0 }}>
          Created by and for{' '}
          <a href="https://github.com/xandermckie" style={{ color: C.primary, textDecoration: 'none', fontWeight: 600 }}>
            Xander McKie
          </a>
        </p>
      </div>
    </footer>
  );
}

/* ── Page Shell ── */
function PageShell({ children }) {
  const { dark } = useTheme();
  const C = TOKENS.colors;
  return (
    <div style={{
      minHeight: '100vh', display: 'flex', flexDirection: 'column',
      background: dark ? C.darkBg : C.bg,
      color: dark ? C.darkText : C.text,
      fontFamily: TOKENS.font.body,
    }}>
      {children}
    </div>
  );
}

function PageContent({ children, wide = false }) {
  return (
    <main style={{
      flex: 1, maxWidth: wide ? 1120 : 800,
      width: '100%', margin: '0 auto',
      padding: '32px 24px 48px',
    }}>
      {children}
    </main>
  );
}

/* ── Celebration overlay ── */
function CelebrationOverlay({ show, message = '¡Excelente!', subtext = '+10 XP', onDone }) {
  const C = TOKENS.colors;
  React.useEffect(() => {
    if (show) {
      const t = setTimeout(() => onDone && onDone(), 1800);
      return () => clearTimeout(t);
    }
  }, [show]);

  if (!show) return null;
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 1000,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(4px)',
      animation: 'celebFadeIn 0.2s ease',
    }}>
      <div style={{
        background: '#fff', borderRadius: TOKENS.radius.xl, padding: '40px 60px',
        textAlign: 'center', boxShadow: C.shadowLg,
        animation: 'celebPop 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
      }}>
        <PezAnimated size={80} expression="celebrating" bobSpeed={1.5} />
        <h2 style={{ fontSize: 28, fontWeight: 800, color: C.text, fontFamily: TOKENS.font.heading, margin: '16px 0 4px' }}>{message}</h2>
        <p style={{ fontSize: 18, fontWeight: 700, color: C.primary, margin: 0 }}>{subtext}</p>
      </div>
    </div>
  );
}

window.TOKENS = TOKENS;
window.ThemeContext = ThemeContext;
window.useTheme = useTheme;
window.Navbar = Navbar;
window.Card = Card;
window.Badge = Badge;
window.Btn = Btn;
window.XPBar = XPBar;
window.StreakBadge = StreakBadge;
window.StatCard = StatCard;
window.RevealCard = RevealCard;
window.SectionHeader = SectionHeader;
window.Footer = Footer;
window.PageShell = PageShell;
window.PageContent = PageContent;
window.CelebrationOverlay = CelebrationOverlay;
