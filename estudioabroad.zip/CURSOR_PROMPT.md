# Cursor Prompt — Estudio Abroad Redesign

Paste this prompt into Cursor to implement the design. Reference the prototype files and CURSOR_HANDOFF.md for details.

---

## The Prompt

```
You are a senior frontend engineer redesigning a Flask/Jinja2 web app called Estudio Abroad — a Spanish learning tool for a college student studying abroad in Barcelona. You have a working interactive prototype (Estudio Abroad.html + its JSX component files) and a detailed handoff document (CURSOR_HANDOFF.md). Your job is to port this design into the existing Flask templates.

**Read these files first:**
- CURSOR_HANDOFF.md — full design system, tokens, component specs, page-by-page guide
- mascot.jsx — Pez fish mascot SVG (port to Jinja2 macro)
- ui-components.jsx — all component patterns and design tokens
- Each page-*.jsx file — layout reference for every page

**Current stack:** Python/Flask + Jinja2 templates, Bootstrap 5 (to be replaced with custom CSS), no frontend framework.

**High-level changes (work feature by feature, commit after each):**

### 1. Replace base.html entirely
- Swap fonts from Playfair Display + Source Serif 4 → DM Sans + Plus Jakarta Sans (Google Fonts)
- Replace all CSS variables with the new design token system (see CURSOR_HANDOFF.md "Colors" section)
- Light mode default (#FAFAF8 background, #1A1A2E text) with dark mode toggle via body.dark class
- New sticky navbar: Pez logo + "Estudio Abroad" brand left, text-only nav links right, dark mode toggle button far right
- Responsive: hamburger menu below 900px
- New footer: Pez (wink) + brand + tagline + cache refresh time + credit link
- Remove all Bootstrap CSS/JS imports — use custom CSS throughout
- Add animations: pezBob keyframes, celebFadeIn, celebPop

### 2. Create Pez mascot partial (templates/partials/pez.html)
- Jinja2 macro: {% macro pez(size=80, expression='happy', speech=None) %}
- SVG fish: red body (#E63946), yellow belly stripe (#FFB627), orange fins (#FF8A65)
- 6 expressions: happy, excited, thinking, sleeping, wink, celebrating
- Optional speech bubble (white card with border)
- Optional .pez-animated wrapper class for bobbing

### 3. Replace click-to-reveal pattern site-wide
- Old: .click-reveal with .click-reveal-es / .click-reveal-en
- New: .reveal-card with .reveal-es / .reveal-en / .reveal-hint
- Animated expand (max-height transition), background shifts to --primary-light when open
- English text in teal (#2EC4B6), italic
- "Tap to reveal English" hint disappears when open
- Do NOT apply to flashcard cards (vocab.html) — those have their own flip mechanic

### 4. Redesign index.html (Home page)
- Hero: Pez greeting with speech bubble + "Buenos días" heading
- Stats grid (4 columns): streak, XP, words learned, accuracy — new StatCard component
- XP progress bar with level badge and streak badge
- Palabra del día: gradient icon square, large Spanish word, tap-to-reveal meaning, example sentence with orange left border
- Frase del día + Frase corta: RevealCard components
- Palabras débiles: list with red miss-count badges, tap to reveal English
- "Continue learning" action cards grid (4 cards linking to other pages)
- New data needed: user_stats object in cache (xp_total, streak_days, level, etc.)

### 5. Redesign reader.html
- New hero section with Pez (thinking expression)
- Restyle passage cards: white background, Badge for language (ES/CA), clean card headers
- Keep fog-reveal clip-path mechanic — just restyle the cursor ring (teal when active, orange when idle)
- Update colors: translation text in teal, surface backgrounds

### 6. Redesign vocab.html (Flashcards)
- Larger flashcard (520px max-width, 36px word, centered)
- "👁 Tap to reveal" pill indicator
- Correct (green) / Missed (red) action buttons after reveal
- Progress bar showing cards completed
- Celebration overlay on correct: Pez celebrating + "¡Correcto!" + "+10 XP" auto-dismiss
- Session complete screen: Pez + score stats + XP earned + missed words recap
- Add XP tracking: +10 per correct answer

### 7. Redesign phrasebook.html
- Clean input card with focus border animation
- Phrase list with hover highlighting, inline edit/delete
- Empty state: Pez (thinking) + helpful message

### 8. Redesign travel.html
- 2-column grid layout (280px filter sidebar + fluid main)
- Restyle filter selects and search button
- Keep Leaflet map — just update container styling (rounded corners, border)
- Result cards with RevealCard for descriptions
- Pez in empty/search states

### 9. Redesign news.html
- Card grid (min 340px columns)
- Each card: 4px gradient top bar (rotating accent colors), clean typography
- Remove Bootstrap card classes, use custom .news-card

### 10. Redesign history.html
- Tab bar with bottom-border active indicator in primary color
- Content card with "Show in English" toggle
- English revealed in teal + italic with left border accent

### 11. Redesign resources.html
- Card grid (min 300px columns)
- Each card: colored top bar, skill Badge, RevealCard for description

### 12. Dark mode
- body.dark class toggles all CSS variables to dark palette
- localStorage persistence for preference
- Toggle button in navbar (☀️/🌙)

### 13. Add gamification system
- New user_stats in cache.json: xp_total, xp_today, xp_daily_goal, level, streak_days, words_learned, accuracy_pct
- Update fetcher.py: add get_user_stats(), update_xp(), update_streak() functions
- XP earned: +10 per correct flashcard, +5 per phrase added, +5 per reader passage read
- Level thresholds: Level 1 (0-99 XP), Level 2 (100-249), Level 3 (250-499), Level 4 (500-999), Level 5 (1000+)
- Streak: increment daily on first activity, reset if a day is missed

**Constraints:**
- Do not break existing Flask routes or fetcher.py caching logic
- Keep all translation API calls cached — no uncached calls
- Port the design faithfully from the prototype files — match colors, spacing, typography exactly
- Test every page after changes
- Commit after each major feature

**Commit sequence:**
1. "Style: New base template with design tokens and Pez mascot"
2. "Style: Redesigned home page with gamification"
3. "Style: Updated reader with new card styling"
4. "Style: Redesigned flashcards with celebration overlay"
5. "Style: Updated phrasebook, travel, news, history, resources"
6. "Feature: Dark mode toggle with localStorage"
7. "Feature: XP and streak tracking system"
```
