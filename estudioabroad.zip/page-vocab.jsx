/* Estudio Abroad — Vocab / Flashcards Page */

function VocabPage() {
  const { dark } = useTheme();
  const C = TOKENS.colors;

  const cards = [
    { es: 'conseguir', en: 'to get, to achieve' },
    { es: 'madrugada', en: 'early morning / dawn' },
    { es: 'disponible', en: 'available' },
    { es: 'averiguar', en: 'to find out' },
    { es: 'desarrollar', en: 'to develop' },
    { es: 'acogedor', en: 'cozy, welcoming' },
    { es: 'aprovechar', en: 'to take advantage of' },
    { es: 'realizar', en: 'to carry out, to accomplish' },
    { es: 'imprescindible', en: 'essential, indispensable' },
    { es: 'entorno', en: 'surroundings, environment' },
  ];

  const [idx, setIdx] = React.useState(0);
  const [flipped, setFlipped] = React.useState(false);
  const [results, setResults] = React.useState([]);
  const [showCeleb, setShowCeleb] = React.useState(false);
  const [sessionDone, setSessionDone] = React.useState(false);

  const card = cards[idx];
  const total = cards.length;

  const handleAnswer = (missed) => {
    setResults(prev => [...prev, { ...card, missed }]);

    if (!missed) {
      setShowCeleb(true);
    }

    setTimeout(() => {
      setFlipped(false);
      if (idx + 1 < total) {
        setIdx(idx + 1);
      } else {
        setSessionDone(true);
      }
    }, missed ? 400 : 1200);
  };

  const restart = () => {
    setIdx(0);
    setFlipped(false);
    setResults([]);
    setSessionDone(false);
  };

  const correct = results.filter(r => !r.missed).length;
  const missed = results.filter(r => r.missed).length;

  if (sessionDone) {
    return (
      <PageContent>
        <div style={{ textAlign: 'center', maxWidth: 480, margin: '0 auto' }}>
          <PezAnimated size={96} expression={correct >= missed ? 'celebrating' : 'thinking'}
            speech={correct >= missed ? '¡Muy bien!' : 'Keep practicing!'} />
          <h1 style={{
            fontSize: 28, fontWeight: 800, fontFamily: TOKENS.font.heading,
            color: dark ? C.darkText : C.text, margin: '24px 0 8px',
          }}>Session Complete</h1>
          <p style={{ fontSize: 15, color: dark ? C.darkTextSecondary : C.textSecondary, marginBottom: 24 }}>
            You reviewed {total} flashcards this session.
          </p>

          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginBottom: 32 }}>
            <StatCard icon="✅" value={correct} label="Correct" color={C.green} />
            <StatCard icon="❌" value={missed} label="Missed" color={C.red} />
          </div>

          {/* XP earned */}
          <Card style={{ marginBottom: 24, textAlign: 'center' }}>
            <p style={{ fontSize: 14, fontWeight: 600, color: C.textSecondary, margin: '0 0 4px' }}>XP Earned</p>
            <p style={{ fontSize: 32, fontWeight: 800, color: C.primary, fontFamily: TOKENS.font.heading, margin: 0 }}>
              +{correct * 10} XP
            </p>
          </Card>

          {/* Missed words recap */}
          {missed > 0 && (
            <>
              <SectionHeader title="Words to review" subtitle="These were marked as missed" />
              <Card style={{ padding: 0, overflow: 'hidden', marginBottom: 24, textAlign: 'left' }}>
                {results.filter(r => r.missed).map((w, i) => (
                  <div key={i} style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    padding: '14px 20px',
                    borderBottom: `1px solid ${dark ? C.darkBorder : C.borderLight}`,
                  }}>
                    <span style={{ fontWeight: 600, fontSize: 15 }}>{w.es}</span>
                    <span style={{ fontSize: 13, color: C.teal, fontStyle: 'italic' }}>{w.en}</span>
                  </div>
                ))}
              </Card>
            </>
          )}

          <Btn onClick={restart} size="lg">Practice Again</Btn>
        </div>
      </PageContent>
    );
  }

  return (
    <PageContent>
      <div style={{ maxWidth: 520, margin: '0 auto' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h1 style={{
            fontSize: 24, fontWeight: 800, fontFamily: TOKENS.font.heading,
            color: dark ? C.darkText : C.text, margin: '0 0 4px',
          }}>Tarjetas</h1>
          <p style={{ fontSize: 14, color: dark ? C.darkTextSecondary : C.textSecondary, margin: 0 }}>
            Spanish first — tap the card to reveal English. Mark what you miss.
          </p>
        </div>

        {/* Progress bar */}
        <div style={{ marginBottom: 20 }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6,
          }}>
            <span style={{ fontSize: 12, fontWeight: 600, color: C.textMuted }}>Card {idx + 1} of {total}</span>
            <span style={{ fontSize: 12, fontWeight: 700, color: C.green }}>
              {correct} correct · <span style={{ color: C.red }}>{missed} missed</span>
            </span>
          </div>
          <div style={{
            height: 6, background: dark ? C.darkSurface2 : '#F3F4F6',
            borderRadius: TOKENS.radius.full, overflow: 'hidden',
          }}>
            <div style={{
              width: `${((idx) / total) * 100}%`, height: '100%',
              background: `linear-gradient(90deg, ${C.teal}, ${C.primary})`,
              borderRadius: TOKENS.radius.full,
              transition: 'width 0.4s ease',
            }} />
          </div>
        </div>

        {/* Flashcard */}
        <div
          onClick={() => !flipped && setFlipped(true)}
          style={{
            background: dark ? C.darkSurface : C.surface,
            border: `2px solid ${flipped ? C.teal + '60' : (dark ? C.darkBorder : C.border)}`,
            borderRadius: TOKENS.radius.xl,
            padding: '48px 32px',
            textAlign: 'center',
            minHeight: 220,
            cursor: flipped ? 'default' : 'pointer',
            transition: 'all 0.3s ease',
            boxShadow: flipped ? `0 4px 20px ${C.teal}15` : C.shadow,
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          }}
        >
          <h2 style={{
            fontSize: 36, fontWeight: 800, color: dark ? C.darkText : C.text,
            fontFamily: TOKENS.font.heading, margin: 0,
            letterSpacing: '-0.02em',
          }}>{card.es}</h2>

          {!flipped && (
            <div style={{
              marginTop: 16, display: 'inline-flex', alignItems: 'center', gap: 6,
              background: dark ? C.darkSurface2 : C.primaryLight,
              padding: '6px 14px', borderRadius: TOKENS.radius.full,
              fontSize: 13, fontWeight: 600, color: C.primary,
            }}>
              <span>👁</span> Tap to reveal
            </div>
          )}

          {flipped && (
            <div style={{
              marginTop: 20, paddingTop: 20,
              borderTop: `1px solid ${dark ? C.darkBorder : C.border}`,
              width: '100%',
              animation: 'celebFadeIn 0.3s ease',
            }}>
              <p style={{
                fontSize: 22, color: C.teal, fontWeight: 600,
                fontFamily: TOKENS.font.body, margin: 0,
              }}>{card.en}</p>
            </div>
          )}
        </div>

        {/* Action buttons */}
        {flipped && (
          <div style={{
            display: 'flex', gap: 12, justifyContent: 'center', marginTop: 20,
            animation: 'celebFadeIn 0.2s ease',
          }}>
            <Btn variant="success" size="lg" onClick={() => handleAnswer(false)}
              style={{ flex: 1, maxWidth: 200 }}>
              ✓ Correct
            </Btn>
            <Btn variant="danger" size="lg" onClick={() => handleAnswer(true)}
              style={{ flex: 1, maxWidth: 200 }}>
              ✗ Missed
            </Btn>
          </div>
        )}

        {/* Pez encouragement */}
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: 24 }}>
          <Pez size={48} expression={flipped ? 'excited' : 'happy'}
            speech={flipped ? '¿Lo sabías?' : null} />
        </div>
      </div>

      <CelebrationOverlay show={showCeleb} message="¡Correcto!" subtext="+10 XP"
        onDone={() => setShowCeleb(false)} />
    </PageContent>
  );
}

window.VocabPage = VocabPage;
