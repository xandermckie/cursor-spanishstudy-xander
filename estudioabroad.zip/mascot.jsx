/* Estudio Abroad — Pez mascot component
   A blocky, cute red-and-yellow fish character */

const FISH_EXPRESSIONS = {
  happy: { eyeScale: 1, mouthCurve: 3, blush: true },
  excited: { eyeScale: 1.15, mouthCurve: 5, blush: true },
  thinking: { eyeScale: 0.9, mouthCurve: 0, blush: false },
  sleeping: { eyeScale: 0.3, mouthCurve: 1, blush: true },
  wink: { eyeScale: 1, mouthCurve: 3, blush: true, wink: true },
  celebrating: { eyeScale: 1.2, mouthCurve: 6, blush: true },
};

function Pez({ size = 80, expression = 'happy', flip = false, style = {}, className = '', speech = null }) {
  const expr = FISH_EXPRESSIONS[expression] || FISH_EXPRESSIONS.happy;
  const s = size;
  const bodyW = s * 0.72;
  const bodyH = s * 0.55;
  const cx = s * 0.48;
  const cy = s * 0.5;
  const r = bodyH * 0.38;

  return (
    <div className={`pez-wrapper ${className}`} style={{ display: 'inline-flex', alignItems: 'flex-end', gap: 8, flexDirection: flip ? 'row-reverse' : 'row', ...style }}>
      {speech && (
        <div style={{
          background: '#fff',
          border: '2px solid #E5E7EB',
          borderRadius: 12,
          padding: '6px 12px',
          fontSize: Math.max(11, s * 0.16),
          color: '#1A1A2E',
          fontWeight: 600,
          maxWidth: 180,
          lineHeight: 1.35,
          boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
          position: 'relative',
        }}>
          {speech}
        </div>
      )}
      <svg
        width={s}
        height={s}
        viewBox={`0 0 ${s} ${s}`}
        fill="none"
        style={{ display: 'block', transform: flip ? 'scaleX(-1)' : 'none' }}
        aria-label="Pez mascot"
      >
        {/* Tail */}
        <polygon
          points={`${cx + bodyW * 0.38},${cy - bodyH * 0.18} ${cx + bodyW * 0.62},${cy - bodyH * 0.42} ${cx + bodyW * 0.62},${cy + bodyH * 0.42} ${cx + bodyW * 0.38},${cy + bodyH * 0.18}`}
          fill="#FFB627"
          rx="3"
        />
        <rect
          x={cx + bodyW * 0.32}
          y={cy - bodyH * 0.22}
          width={bodyW * 0.12}
          height={bodyH * 0.44}
          rx={3}
          fill="#F59E0B"
        />

        {/* Body */}
        <rect
          x={cx - bodyW * 0.42}
          y={cy - bodyH * 0.42}
          width={bodyW * 0.78}
          height={bodyH * 0.84}
          rx={r}
          fill="#E63946"
        />

        {/* Belly stripe */}
        <rect
          x={cx - bodyW * 0.32}
          y={cy + bodyH * 0.02}
          width={bodyW * 0.58}
          height={bodyH * 0.24}
          rx={bodyH * 0.12}
          fill="#FFB627"
          opacity="0.85"
        />

        {/* Top fin */}
        <ellipse
          cx={cx - bodyW * 0.02}
          cy={cy - bodyH * 0.42}
          rx={bodyW * 0.1}
          ry={bodyH * 0.18}
          fill="#FF8A65"
        />

        {/* Side fin */}
        <ellipse
          cx={cx - bodyW * 0.32}
          cy={cy + bodyH * 0.08}
          rx={bodyW * 0.12}
          ry={bodyH * 0.1}
          fill="#FF8A65"
          transform={`rotate(-20 ${cx - bodyW * 0.32} ${cy + bodyH * 0.08})`}
        />

        {/* Eye white */}
        <circle
          cx={cx - bodyW * 0.14}
          cy={cy - bodyH * 0.1}
          r={s * 0.09 * expr.eyeScale}
          fill="#fff"
        />

        {/* Pupil */}
        {expr.wink ? (
          <line
            x1={cx - bodyW * 0.2}
            y1={cy - bodyH * 0.1}
            x2={cx - bodyW * 0.08}
            y2={cy - bodyH * 0.1}
            stroke="#1A1A2E"
            strokeWidth={2.5}
            strokeLinecap="round"
          />
        ) : (
          <circle
            cx={cx - bodyW * 0.12}
            cy={cy - bodyH * 0.08}
            r={s * 0.05 * expr.eyeScale}
            fill="#1A1A2E"
          />
        )}

        {/* Eye shine */}
        {!expr.wink && (
          <circle
            cx={cx - bodyW * 0.1}
            cy={cy - bodyH * 0.14}
            r={s * 0.02}
            fill="#fff"
          />
        )}

        {/* Blush */}
        {expr.blush && (
          <circle
            cx={cx - bodyW * 0.26}
            cy={cy + bodyH * 0.04}
            r={s * 0.04}
            fill="#FF8A65"
            opacity="0.5"
          />
        )}

        {/* Mouth */}
        <path
          d={`M ${cx - bodyW * 0.2} ${cy + bodyH * 0.12} Q ${cx - bodyW * 0.12} ${cy + bodyH * 0.12 + expr.mouthCurve} ${cx - bodyW * 0.04} ${cy + bodyH * 0.12}`}
          stroke="#1A1A2E"
          strokeWidth={1.8}
          strokeLinecap="round"
          fill="none"
        />
      </svg>
    </div>
  );
}

/* Pez with bobbing animation */
function PezAnimated({ bobSpeed = 3, ...props }) {
  const id = React.useRef('pez-' + Math.random().toString(36).slice(2, 7));
  return (
    <div style={{ animation: `pezBob ${bobSpeed}s ease-in-out infinite` }} className={id.current}>
      <Pez {...props} />
    </div>
  );
}

window.Pez = Pez;
window.PezAnimated = PezAnimated;
