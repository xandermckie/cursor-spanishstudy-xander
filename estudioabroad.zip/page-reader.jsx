/* Estudio Abroad — Reader Page (Fog-Reveal) */

function ReaderPage() {
  const { dark } = useTheme();
  const C = TOKENS.colors;
  const [activePassage, setActivePassage] = React.useState(null);
  const [cursorPos, setCursorPos] = React.useState({ x: -100, y: -100 });
  const [lensActive, setLensActive] = React.useState(false);

  const passages = [
    {
      id: 1, lang: 'ES', title: 'En el Mercado de la Boquería',
      body: 'El Mercado de la Boquería es uno de los mercados más famosos de Barcelona. Situado en Las Ramblas, ofrece una gran variedad de frutas frescas, mariscos, jamón ibérico y zumos naturales. Los vendedores gritan sus ofertas mientras los turistas pasean entre los puestos coloridos. Es el lugar perfecto para practicar español y descubrir la gastronomía catalana.',
      en: 'The Boquería Market is one of the most famous markets in Barcelona. Located on Las Ramblas, it offers a great variety of fresh fruits, seafood, Iberian ham, and natural juices. The vendors shout their deals while tourists stroll between the colorful stalls. It\'s the perfect place to practice Spanish and discover Catalan cuisine.',
    },
    {
      id: 2, lang: 'ES', title: 'El Metro de Barcelona',
      body: 'Para moverse por Barcelona, el metro es la opción más práctica. Hay ocho líneas que conectan toda la ciudad. Una tarjeta T-casual cuesta unos diez euros y permite diez viajes. Las estaciones están bien señalizadas en catalán y castellano. Recuerda validar tu billete antes de entrar al andén.',
      en: 'To get around Barcelona, the metro is the most practical option. There are eight lines that connect the entire city. A T-casual card costs about ten euros and allows ten trips. The stations are well signposted in Catalan and Spanish. Remember to validate your ticket before entering the platform.',
    },
    {
      id: 3, lang: 'CA', title: 'La Universitat de Barcelona',
      body: 'La Universitat de Barcelona és una de les universitats més antigues de Catalunya. Fundada el 1450, es troba al cor de la ciutat. Els estudiants internacionals poden gaudir dels seus jardins, biblioteques i edificis històrics mentre estudien.',
      en: 'The University of Barcelona is one of the oldest universities in Catalonia. Founded in 1450, it is located in the heart of the city. International students can enjoy its gardens, libraries, and historic buildings while they study.',
    },
  ];

  const handleMouseMove = React.useCallback((e) => {
    setCursorPos({ x: e.clientX, y: e.clientY });
  }, []);

  React.useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    return () => document.removeEventListener('mousemove', handleMouseMove);
  }, [handleMouseMove]);

  return (
    <PageContent>
      {/* Custom cursor */}
      <div style={{
        position: 'fixed',
        left: cursorPos.x, top: cursorPos.y,
        width: lensActive ? 160 : 36, height: lensActive ? 160 : 36,
        border: `2px solid ${lensActive ? C.teal : C.primary}`,
        borderRadius: '50%',
        pointerEvents: 'none',
        zIndex: 9999,
        transform: 'translate(-50%, -50%)',
        transition: 'width 0.15s ease, height 0.15s ease, border-color 0.15s ease, opacity 0.12s ease',
        boxShadow: lensActive ? `0 0 24px ${C.teal}40` : `0 0 12px ${C.primary}35`,
        opacity: lensActive ? 1 : 0,
      }} />

      {/* Hero */}
      <div style={{ textAlign: 'center', marginBottom: 32 }}>
        <div style={{ marginBottom: 12 }}>
          <PezAnimated size={56} expression="thinking" />
        </div>
        <div style={{
          fontSize: 11, letterSpacing: '0.3em', textTransform: 'uppercase',
          color: C.primary, fontWeight: 700, marginBottom: 8, fontFamily: TOKENS.font.heading,
        }}>Estudio Abroad Reader</div>
        <h1 style={{
          fontSize: 32, fontWeight: 800, color: dark ? C.darkText : C.text,
          fontFamily: TOKENS.font.heading, margin: '0 0 8px', letterSpacing: '-0.02em',
        }}>
          Read in Spanish. <span style={{ color: C.primary }}>Hover to remember.</span>
        </h1>
        <p style={{
          fontSize: 15, color: dark ? C.darkTextSecondary : C.textSecondary,
          maxWidth: 480, margin: '0 auto', lineHeight: 1.6,
        }}>
          Move your cursor over the passage — a lens reveals the English translation hidden beneath.
        </p>
      </div>

      {/* Instruction hint */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        background: dark ? C.darkSurface : C.primaryLight,
        border: `1px solid ${C.primary}25`,
        borderRadius: TOKENS.radius.md,
        padding: '12px 18px', marginBottom: 24,
        fontSize: 13, fontWeight: 600, color: C.primary,
        fontFamily: TOKENS.font.body,
      }}>
        <span style={{ fontSize: 20 }}>◎</span>
        Hover over the passage — the fog clears where your cursor moves
      </div>

      {/* Passages */}
      {passages.map((p) => (
        <Card key={p.id} style={{ marginBottom: 16, padding: 0, overflow: 'hidden' }}>
          <div style={{
            padding: '12px 24px',
            borderBottom: `1px solid ${dark ? C.darkBorder : C.borderLight}`,
            display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <Badge color={p.lang === 'CA' ? 'teal' : 'primary'}>{p.lang}</Badge>
            <span style={{
              fontSize: 12, letterSpacing: '0.15em', textTransform: 'uppercase',
              color: dark ? C.darkTextSecondary : C.textMuted, fontWeight: 600,
            }}>{p.title}</span>
          </div>

          <div
            style={{
              position: 'relative', padding: '24px 28px',
              cursor: 'none', overflow: 'hidden', minHeight: 120,
            }}
            onMouseEnter={() => { setActivePassage(p.id); setLensActive(true); }}
            onMouseLeave={() => { setActivePassage(null); setLensActive(false); }}
            onMouseMove={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              e.currentTarget.style.setProperty('--cx', (e.clientX - rect.left) + 'px');
              e.currentTarget.style.setProperty('--cy', (e.clientY - rect.top) + 'px');
            }}
          >
            {/* Spanish layer */}
            <p style={{
              fontSize: 17, lineHeight: 1.9, color: dark ? C.darkText : C.text,
              fontFamily: TOKENS.font.body, margin: 0, position: 'relative', zIndex: 1,
            }}>{p.body}</p>

            {/* English layer (revealed by clip-path) */}
            <p style={{
              fontSize: 17, lineHeight: 1.9, color: C.teal, fontStyle: 'italic',
              fontFamily: TOKENS.font.body, margin: 0,
              position: 'absolute', top: 24, left: 28, right: 28,
              zIndex: 2, pointerEvents: 'none',
              background: dark ? C.darkSurface : C.surface,
              clipPath: activePassage === p.id
                ? 'circle(80px at var(--cx, 50%) var(--cy, 50%))'
                : 'circle(0px at var(--cx, 50%) var(--cy, 50%))',
              transition: 'clip-path 0.08s ease',
            }}>{p.en}</p>
          </div>
        </Card>
      ))}

      {/* Weak words from flashcards */}
      <SectionHeader title="Palabras débiles" subtitle="From your flashcard sessions" style={{ marginTop: 32 }} />
      <Card style={{ padding: 0, overflow: 'hidden' }}>
        {[
          { es: 'conseguir', misses: 5 },
          { es: 'desarrollar', misses: 4 },
          { es: 'averiguar', misses: 3 },
        ].map((w, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '12px 20px',
            borderBottom: i < 2 ? `1px solid ${dark ? C.darkBorder : C.borderLight}` : 'none',
          }}>
            <span style={{ fontWeight: 600, fontSize: 15 }}>{w.es}</span>
            <Badge color="red">{w.misses} misses</Badge>
          </div>
        ))}
        <div style={{ padding: '12px 20px', textAlign: 'center' }}>
          <Btn variant="ghost" size="sm" onClick={() => window.__navigate && window.__navigate('vocab')}>
            Practice flashcards →
          </Btn>
        </div>
      </Card>
    </PageContent>
  );
}

window.ReaderPage = ReaderPage;
