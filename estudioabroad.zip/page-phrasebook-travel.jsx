/* Estudio Abroad — Phrasebook + Travel Pages */

/* ── Phrasebook ── */
function PhrasebookPage() {
  const { dark } = useTheme();
  const C = TOKENS.colors;
  const [phrases, setPhrases] = React.useState([
    { id: '1', input: 'I need to renew my student visa', es: 'Necesito renovar mi visa de estudiante' },
    { id: '2', input: 'Where can I buy a metro pass?', es: '¿Dónde puedo comprar un abono de metro?' },
    { id: '3', input: 'Can I have the bill please?', es: '¿Me puede traer la cuenta, por favor?' },
    { id: '4', input: 'I have a reservation under my name', es: 'Tengo una reserva a mi nombre' },
    { id: '5', input: 'What time does the library close?', es: '¿A qué hora cierra la biblioteca?' },
  ]);
  const [input, setInput] = React.useState('');
  const [editId, setEditId] = React.useState(null);
  const [editText, setEditText] = React.useState('');

  const addPhrase = () => {
    if (!input.trim()) return;
    const fakeEs = '(traducción de) ' + input.trim();
    setPhrases(prev => [{ id: Date.now().toString(), input: input.trim(), es: fakeEs }, ...prev]);
    setInput('');
  };

  const deletePhrase = (id) => {
    setPhrases(prev => prev.filter(p => p.id !== id));
  };

  const saveEdit = (id) => {
    setPhrases(prev => prev.map(p => p.id === id ? { ...p, input: editText } : p));
    setEditId(null);
  };

  return (
    <PageContent>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12, marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, fontFamily: TOKENS.font.heading, color: dark ? C.darkText : C.text, margin: 0 }}>
            Libro de frases
          </h1>
          <p style={{ fontSize: 14, color: dark ? C.darkTextSecondary : C.textSecondary, margin: '4px 0 0' }}>
            Type in English — get the Spanish translation saved.
          </p>
        </div>
        <Btn variant="secondary" size="sm">📥 Export CSV</Btn>
      </div>

      {/* Add phrase */}
      <Card style={{ marginBottom: 24, padding: 20 }}>
        <label style={{ fontSize: 13, fontWeight: 600, color: dark ? C.darkTextSecondary : C.textSecondary, marginBottom: 8, display: 'block' }}>
          Enter phrase in English
        </label>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && addPhrase()}
            placeholder="e.g. I need to renew my student visa"
            style={{
              flex: 1, padding: '10px 16px', fontSize: 14,
              border: `1px solid ${dark ? C.darkBorder : C.border}`,
              borderRadius: TOKENS.radius.md,
              background: dark ? C.darkBg : '#FAFAFA',
              color: dark ? C.darkText : C.text,
              fontFamily: TOKENS.font.body, outline: 'none',
            }}
            onFocus={e => e.target.style.borderColor = C.primary}
            onBlur={e => e.target.style.borderColor = dark ? C.darkBorder : C.border}
          />
          <Btn onClick={addPhrase}>Translate & Save</Btn>
        </div>
        <p style={{ fontSize: 12, color: C.textMuted, margin: '8px 0 0' }}>
          Translation is cached to avoid repeated API calls.
        </p>
      </Card>

      {/* Hint */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        background: dark ? C.darkSurface : C.primaryLight,
        border: `1px solid ${C.primary}20`, borderRadius: TOKENS.radius.md,
        padding: '10px 16px', marginBottom: 20, fontSize: 13, fontWeight: 600, color: C.primary,
      }}>
        <span style={{ fontSize: 16 }}>◎</span> Tap any phrase to reveal the English original
      </div>

      {/* Phrases list */}
      <Card style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{
          padding: '12px 20px', borderBottom: `1px solid ${dark ? C.darkBorder : C.borderLight}`,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: dark ? C.darkTextSecondary : C.textSecondary }}>
            Your phrases ({phrases.length})
          </span>
        </div>

        {phrases.length === 0 ? (
          <div style={{ padding: 32, textAlign: 'center' }}>
            <Pez size={48} expression="thinking" />
            <p style={{ fontSize: 14, color: C.textMuted, marginTop: 12 }}>No phrases yet. Add your first one above.</p>
          </div>
        ) : (
          phrases.map((p, i) => (
            <PhraseRow key={p.id} phrase={p} isLast={i === phrases.length - 1}
              editId={editId} editText={editText} setEditId={setEditId}
              setEditText={setEditText} saveEdit={saveEdit} deletePhrase={deletePhrase} />
          ))
        )}
      </Card>
    </PageContent>
  );
}

function PhraseRow({ phrase: p, isLast, editId, editText, setEditId, setEditText, saveEdit, deletePhrase }) {
  const { dark } = useTheme();
  const C = TOKENS.colors;
  const [open, setOpen] = React.useState(false);

  return (
    <div style={{ borderBottom: isLast ? 'none' : `1px solid ${dark ? C.darkBorder : C.borderLight}` }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 12, padding: '14px 20px', cursor: 'pointer',
      }}
        onClick={() => setOpen(!open)}
        onMouseEnter={e => e.currentTarget.style.background = dark ? C.darkSurface2 : '#FAFAFA'}
        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
      >
        <div style={{ flex: 1 }}>
          <span style={{ fontSize: 16, fontWeight: 600, color: dark ? C.darkText : C.text }}>{p.es}</span>
          {open && (
            <div style={{ marginTop: 6, fontSize: 14, color: C.teal, fontStyle: 'italic', animation: 'celebFadeIn 0.2s ease' }}>
              {p.input}
            </div>
          )}
        </div>
        <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
          <button onClick={e => { e.stopPropagation(); setEditId(p.id); setEditText(p.input); }} style={{
            background: dark ? C.darkSurface2 : '#F3F4F6', border: 'none', borderRadius: TOKENS.radius.sm,
            padding: '6px 12px', fontSize: 12, fontWeight: 600, cursor: 'pointer',
            color: dark ? C.darkText : C.text,
          }}>Edit</button>
          <button onClick={e => { e.stopPropagation(); deletePhrase(p.id); }} style={{
            background: '#FEF2F2', border: 'none', borderRadius: TOKENS.radius.sm,
            padding: '6px 12px', fontSize: 12, fontWeight: 600, cursor: 'pointer', color: C.red,
          }}>Delete</button>
        </div>
      </div>
      {editId === p.id && (
        <div style={{ padding: '0 20px 14px', display: 'flex', gap: 8 }}>
          <input value={editText} onChange={e => setEditText(e.target.value)}
            style={{
              flex: 1, padding: '8px 12px', fontSize: 13,
              border: `1px solid ${dark ? C.darkBorder : C.border}`,
              borderRadius: TOKENS.radius.sm,
              background: dark ? C.darkBg : '#fff', color: dark ? C.darkText : C.text,
              fontFamily: TOKENS.font.body, outline: 'none',
            }} />
          <Btn size="sm" onClick={() => saveEdit(p.id)}>Save</Btn>
          <Btn variant="ghost" size="sm" onClick={() => setEditId(null)}>Cancel</Btn>
        </div>
      )}
    </div>
  );
}

/* ── Travel ── */
function TravelPage() {
  const { dark } = useTheme();
  const C = TOKENS.colors;
  const [searched, setSearched] = React.useState(false);
  const [filters, setFilters] = React.useState({ time: '', location: '', distance: '', mood: '' });

  const recs = [
    { name: 'Mercat de la Boquería', addr: 'La Rambla, 91 · 10 min walk', descEs: 'El mercado más icónico de Barcelona. Prueba zumos frescos, jamón ibérico y frutas tropicales.', descEn: 'Barcelona\'s most iconic market. Try fresh juices, Iberian ham, and tropical fruits.', mood: 'hungry' },
    { name: 'Bunkers del Carmel', addr: 'Carrer de Marià Lavèrnia · 25 min transit', descEs: 'Las mejores vistas panorámicas de Barcelona. Perfecto para un atardecer tranquilo.', descEn: 'The best panoramic views of Barcelona. Perfect for a quiet sunset.', mood: 'chill' },
    { name: 'Barri Gòtic', addr: 'Gothic Quarter · 15 min walk', descEs: 'Piérdete por las calles medievales del casco antiguo. Arquitectura gótica y plazas escondidas.', descEn: 'Get lost in the medieval streets of the old town. Gothic architecture and hidden squares.', mood: 'adventure' },
    { name: 'MACBA', addr: 'Plaça dels Àngels, 1 · 12 min walk', descEs: 'Museo de Arte Contemporáneo de Barcelona. Exposiciones rotativas de artistas internacionales.', descEn: 'Barcelona Museum of Contemporary Art. Rotating exhibitions from international artists.', mood: 'cultural' },
  ];

  const filteredRecs = searched ? recs.filter(r => !filters.mood || r.mood === filters.mood) : [];

  const SelectField = ({ label, name, options }) => (
    <div style={{ marginBottom: 14 }}>
      <label style={{ fontSize: 12, fontWeight: 600, color: dark ? C.darkTextSecondary : C.textSecondary, display: 'block', marginBottom: 4 }}>{label}</label>
      <select
        value={filters[name]}
        onChange={e => setFilters(prev => ({ ...prev, [name]: e.target.value }))}
        style={{
          width: '100%', padding: '8px 12px', fontSize: 13,
          border: `1px solid ${dark ? C.darkBorder : C.border}`,
          borderRadius: TOKENS.radius.sm, fontFamily: TOKENS.font.body,
          background: dark ? C.darkBg : '#fff', color: dark ? C.darkText : C.text,
        }}
      >
        <option value="">— Any —</option>
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );

  return (
    <PageContent wide>
      <h1 style={{ fontSize: 24, fontWeight: 800, fontFamily: TOKENS.font.heading, color: dark ? C.darkText : C.text, margin: '0 0 4px' }}>
        Viajes y recomendaciones
      </h1>
      <p style={{ fontSize: 14, color: dark ? C.darkTextSecondary : C.textSecondary, margin: '0 0 24px' }}>
        Places near Universitat de Barcelona and around the city.
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 24, alignItems: 'start' }} className="travel-grid">
        {/* Filters */}
        <Card style={{ padding: 20 }}>
          <h2 style={{ fontSize: 15, fontWeight: 700, color: C.primary, margin: '0 0 16px', fontFamily: TOKENS.font.heading }}>Filters</h2>
          <SelectField label="Time available" name="time" options={[
            { value: '1-2h', label: '1–2 hours' }, { value: 'half', label: 'Half day' }, { value: 'full', label: 'Full day' },
          ]} />
          <SelectField label="Current location" name="location" options={[
            { value: 'ub', label: 'At Universitat de Barcelona' }, { value: 'barcelona', label: 'Elsewhere in Barcelona' },
          ]} />
          <SelectField label="Walking distance" name="distance" options={[
            { value: 'walk', label: 'Walking (< 1 km)' }, { value: 'transit', label: 'Short transit (1–5 km)' },
          ]} />
          <SelectField label="Mood" name="mood" options={[
            { value: 'hungry', label: '🍽️ Hungry' }, { value: 'adventure', label: '🧭 Adventure' },
            { value: 'chill', label: '☀️ Relax' }, { value: 'cultural', label: '🎨 Cultural' },
          ]} />
          <Btn onClick={() => setSearched(true)} style={{ width: '100%', marginTop: 8 }}>Search</Btn>
        </Card>

        {/* Results + Map */}
        <div>
          {/* Map placeholder */}
          <div style={{
            width: '100%', height: 300, borderRadius: TOKENS.radius.lg,
            border: `1px solid ${dark ? C.darkBorder : C.border}`,
            background: dark ? C.darkSurface2 : '#EEF2F7',
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            marginBottom: 20, overflow: 'hidden',
            backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 20px, rgba(0,0,0,0.02) 20px, rgba(0,0,0,0.02) 40px)',
          }}>
            <span style={{ fontSize: 40, marginBottom: 8 }}>🗺️</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: C.textMuted, fontFamily: 'monospace' }}>
              Leaflet Map — Barcelona
            </span>
            <span style={{ fontSize: 11, color: C.textMuted }}>41.3874° N, 2.1686° E</span>
          </div>

          {searched ? (
            filteredRecs.length > 0 ? (
              <>
                <SectionHeader title={`Recommendations (${filteredRecs.length})`} />
                {filteredRecs.map((r, i) => (
                  <Card key={i} style={{ marginBottom: 12, padding: 20 }}>
                    <h3 style={{ fontSize: 17, fontWeight: 700, margin: '0 0 4px', color: dark ? C.darkText : C.text }}>{r.name}</h3>
                    <p style={{ fontSize: 13, color: C.textMuted, margin: '0 0 10px' }}>{r.addr}</p>
                    <RevealCard spanish={r.descEs} english={r.descEn} style={{ marginBottom: 10, border: 'none', padding: '12px 0' }} />
                    <a href="#" style={{ color: C.teal, fontSize: 13, fontWeight: 600, textDecoration: 'none' }}>
                      Open in Google Maps →
                    </a>
                  </Card>
                ))}
              </>
            ) : (
              <div style={{ textAlign: 'center', padding: 40 }}>
                <Pez size={56} expression="thinking" speech="No results — try different filters!" />
              </div>
            )
          ) : (
            <div style={{ textAlign: 'center', padding: 40 }}>
              <Pez size={56} expression="happy" speech="Choose filters and search!" />
            </div>
          )}
        </div>
      </div>
    </PageContent>
  );
}

window.PhrasebookPage = PhrasebookPage;
window.TravelPage = TravelPage;
