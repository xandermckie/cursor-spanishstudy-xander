/* Estudio Abroad — News, History, Resources Pages */

/* ── News ── */
function NewsPage() {
  const { dark } = useTheme();
  const C = TOKENS.colors;

  const articles = [
    { title: 'Barcelona amplía la red de carriles bici en el Eixample', source: 'La Vanguardia', date: '3 Jun 2026', desc: 'El Ayuntamiento aprueba la construcción de 12 nuevos kilómetros de carriles bici que conectarán los principales barrios de la ciudad.' },
    { title: 'La Sagrada Familia completará su torre principal en 2027', source: 'El País', date: '2 Jun 2026', desc: 'La basílica diseñada por Antoni Gaudí alcanzará finalmente su altura máxima de 172 metros con la torre de Jesucristo.' },
    { title: 'Nuevo récord de estudiantes internacionales en universidades catalanas', source: 'El Periódico', date: '1 Jun 2026', desc: 'Las universidades de Cataluña acogen este curso a más de 45.000 estudiantes de intercambio, un 15% más que el año anterior.' },
    { title: 'El precio del alquiler en Barcelona se estabiliza tras nuevas regulaciones', source: 'Ara', date: '31 May 2026', desc: 'Las medidas de control de precios del Govern muestran sus primeros efectos con una reducción del 3% en el precio medio.' },
    { title: 'La Boquería renueva su zona de frutas y productos locales', source: 'Betevé', date: '30 May 2026', desc: 'El mercado más visitado de Barcelona moderniza sus instalaciones manteniendo la esencia del comercio tradicional.' },
    { title: 'Festival de música Primavera Sound anuncia cartel para 2027', source: 'NacióDigital', date: '29 May 2026', desc: 'El festival barcelonés confirma sus primeros cabezas de cartel para la próxima edición en el Parc del Fòrum.' },
  ];

  return (
    <PageContent wide>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, fontFamily: TOKENS.font.heading, color: dark ? C.darkText : C.text, margin: 0 }}>
            Noticias de España
          </h1>
          <p style={{ fontSize: 14, color: dark ? C.darkTextSecondary : C.textSecondary, margin: '4px 0 0' }}>
            Headlines in Spanish from Spanish media — practice reading real news.
          </p>
        </div>
        <div style={{ marginLeft: 'auto' }}>
          <Pez size={40} expression="happy" />
        </div>
      </div>

      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))',
        gap: 16,
      }}>
        {articles.map((a, i) => (
          <Card key={i} hover style={{ padding: 0, display: 'flex', flexDirection: 'column' }}>
            {/* Colored top bar */}
            <div style={{
              height: 4,
              background: `linear-gradient(90deg, ${[C.primary, C.secondary, C.teal, C.red, '#8B5CF6', C.green][i % 6]}, ${[C.secondary, C.primary, C.primary, C.secondary, C.teal, C.teal][i % 6]})`,
              borderRadius: `${TOKENS.radius.lg}px ${TOKENS.radius.lg}px 0 0`,
            }} />
            <div style={{ padding: 22, flex: 1, display: 'flex', flexDirection: 'column' }}>
              <h2 style={{
                fontSize: 16, fontWeight: 700, color: dark ? C.darkText : C.text,
                fontFamily: TOKENS.font.heading, margin: '0 0 8px', lineHeight: 1.35,
              }}>{a.title}</h2>
              <p style={{ fontSize: 12, color: C.textMuted, margin: '0 0 10px', fontWeight: 600 }}>
                {a.source} · {a.date}
              </p>
              <p style={{
                fontSize: 14, color: dark ? C.darkTextSecondary : C.textSecondary,
                margin: '0 0 16px', lineHeight: 1.55, flex: 1,
              }}>{a.desc}</p>
              <Btn variant="secondary" size="sm" style={{ alignSelf: 'flex-start' }}>
                Leer más →
              </Btn>
            </div>
          </Card>
        ))}
      </div>

      <div style={{ textAlign: 'center', marginTop: 24 }}>
        <p style={{ fontSize: 12, color: C.textMuted }}>
          News from NewsAPI · Cached for 60 minutes
        </p>
      </div>
    </PageContent>
  );
}

/* ── History ── */
function HistoryPage() {
  const { dark } = useTheme();
  const C = TOKENS.colors;
  const [activeTab, setActiveTab] = React.useState(0);

  const topics = [
    {
      key: 'reconquista', titleEs: 'La Reconquista', introEs: 'Ocho siglos de historia que definieron la península.',
      summaryEs: 'La Reconquista fue un largo periodo de casi 800 años durante el cual los reinos cristianos del norte de la península ibérica recuperaron progresivamente los territorios que habían sido conquistados por los musulmanes a partir del año 711. Este proceso culminó en 1492 con la caída del Reino de Granada.',
      summaryEn: 'The Reconquista was a long period of almost 800 years during which the Christian kingdoms of the northern Iberian Peninsula progressively recovered the territories that had been conquered by the Muslims from the year 711. This process culminated in 1492 with the fall of the Kingdom of Granada.',
    },
    {
      key: 'guerra-civil', titleEs: 'La Guerra Civil', introEs: 'El conflicto que marcó el siglo XX español.',
      summaryEs: 'La Guerra Civil Española (1936–1939) enfrentó al gobierno republicano con las fuerzas nacionalistas lideradas por el general Francisco Franco. Barcelona fue un bastión republicano y sufrió bombardeos devastadores. La guerra terminó con la dictadura de Franco.',
      summaryEn: 'The Spanish Civil War (1936–1939) pitted the republican government against nationalist forces led by General Francisco Franco. Barcelona was a republican stronghold and suffered devastating bombings. The war ended with Franco\'s dictatorship.',
    },
    {
      key: 'cataluna', titleEs: 'Cataluña y España', introEs: 'La compleja relación entre Cataluña y el estado español.',
      summaryEs: 'Cataluña ha mantenido una identidad cultural y lingüística propia a lo largo de la historia. El catalán es la lengua cooficial junto con el castellano. El movimiento independentista ha ganado fuerza en el siglo XXI, especialmente tras el referéndum de 2017.',
      summaryEn: 'Catalonia has maintained its own cultural and linguistic identity throughout history. Catalan is the co-official language alongside Spanish. The independence movement has gained strength in the 21st century, especially after the 2017 referendum.',
    },
    {
      key: 'modernisme', titleEs: 'El Modernisme', introEs: 'El movimiento artístico que transformó Barcelona.',
      summaryEs: 'El Modernisme catalán fue un movimiento artístico y cultural de finales del siglo XIX y principios del XX. Antoni Gaudí, Lluís Domènech i Montaner y Josep Puig i Cadafalch transformaron Barcelona con edificios extraordinarios como la Sagrada Familia, el Hospital de Sant Pau y la Casa Amatller.',
      summaryEn: 'Catalan Modernisme was an artistic and cultural movement of the late 19th and early 20th centuries. Antoni Gaudí, Lluís Domènech i Montaner and Josep Puig i Cadafalch transformed Barcelona with extraordinary buildings such as the Sagrada Familia, Hospital de Sant Pau, and Casa Amatller.',
    },
  ];

  const topic = topics[activeTab];

  return (
    <PageContent>
      <h1 style={{ fontSize: 24, fontWeight: 800, fontFamily: TOKENS.font.heading, color: dark ? C.darkText : C.text, margin: '0 0 4px' }}>
        Historia de España
      </h1>
      <p style={{ fontSize: 14, color: dark ? C.darkTextSecondary : C.textSecondary, margin: '0 0 24px' }}>
        Key topics to understand Spanish and Catalan culture.
      </p>

      {/* Tabs */}
      <div style={{
        display: 'flex', gap: 4, marginBottom: 20, overflowX: 'auto',
        borderBottom: `1px solid ${dark ? C.darkBorder : C.border}`, paddingBottom: 0,
      }}>
        {topics.map((t, i) => (
          <button key={t.key} onClick={() => setActiveTab(i)} style={{
            padding: '10px 18px', fontSize: 13, fontWeight: activeTab === i ? 700 : 500,
            color: activeTab === i ? C.primary : (dark ? C.darkTextSecondary : C.textSecondary),
            background: 'transparent', border: 'none',
            borderBottom: activeTab === i ? `2px solid ${C.primary}` : '2px solid transparent',
            cursor: 'pointer', fontFamily: TOKENS.font.body, whiteSpace: 'nowrap',
            transition: 'all 0.15s ease', marginBottom: -1,
          }}>{t.titleEs}</button>
        ))}
      </div>

      {/* Active topic */}
      <Card style={{ padding: 28 }}>
        <h2 style={{ fontSize: 22, fontWeight: 800, fontFamily: TOKENS.font.heading, color: dark ? C.darkText : C.text, margin: '0 0 6px' }}>
          {topic.titleEs}
        </h2>
        <p style={{ fontSize: 14, color: C.textMuted, margin: '0 0 16px' }}>{topic.introEs}</p>

        <p style={{ fontSize: 16, lineHeight: 1.8, color: dark ? C.darkText : C.text, margin: '0 0 20px' }}>
          {topic.summaryEs}
        </p>

        <HistoryEnReveal summaryEn={topic.summaryEn} />

        <a href="#" style={{ color: C.primary, fontSize: 13, fontWeight: 600, textDecoration: 'none' }}>
          Read more on Wikipedia →
        </a>
      </Card>
    </PageContent>
  );
}

function HistoryEnReveal({ summaryEn }) {
  const [show, setShow] = React.useState(false);
  const C = TOKENS.colors;
  const { dark } = useTheme();
  return (
    <div style={{ marginBottom: 16 }}>
      <Btn variant={show ? 'ghost' : 'primary'} size="sm" onClick={() => setShow(!show)}>
        {show ? 'Hide English' : 'Show in English'}
      </Btn>
      {show && (
        <p style={{
          fontSize: 15, lineHeight: 1.75, color: C.teal, fontStyle: 'italic',
          marginTop: 12, paddingLeft: 16,
          borderLeft: `3px solid ${C.teal}40`,
          animation: 'celebFadeIn 0.3s ease',
        }}>
          {summaryEn}
        </p>
      )}
    </div>
  );
}

/* ── Resources ── */
function ResourcesPage() {
  const { dark } = useTheme();
  const C = TOKENS.colors;

  const resources = [
    { name: 'SpanishDict', skill: 'Vocabulario', descEs: 'Diccionario completo con conjugaciones, traducciones y ejemplos de uso para cada palabra.', descEn: 'Complete dictionary with conjugations, translations, and usage examples for every word.', url: 'https://spanishdict.com', color: C.primary },
    { name: 'Forvo', skill: 'Pronunciación', descEs: 'Escucha la pronunciación de palabras en español por hablantes nativos de diferentes países.', descEn: 'Listen to pronunciation of Spanish words by native speakers from different countries.', url: 'https://forvo.com', color: C.teal },
    { name: 'Reverso Context', skill: 'Contexto', descEs: 'Encuentra traducciones en contexto real con millones de ejemplos de textos bilingües.', descEn: 'Find translations in real context with millions of examples from bilingual texts.', url: 'https://context.reverso.net', color: C.secondary },
    { name: 'News in Slow Spanish', skill: 'Listening', descEs: 'Podcast de noticias en español a velocidad reducida, perfecto para estudiantes intermedios.', descEn: 'Spanish news podcast at reduced speed, perfect for intermediate students.', url: '#', color: '#8B5CF6' },
    { name: 'Practiquemos', skill: 'Gramática', descEs: 'Ejercicios interactivos de gramática española con explicaciones claras y progresivas.', descEn: 'Interactive Spanish grammar exercises with clear and progressive explanations.', url: '#', color: C.green },
    { name: 'WordReference', skill: 'Vocabulario', descEs: 'Foros de discusión lingüística y diccionario con matices de uso y expresiones coloquiales.', descEn: 'Linguistic discussion forums and dictionary with usage nuances and colloquial expressions.', url: 'https://wordreference.com', color: C.red },
  ];

  return (
    <PageContent wide>
      <h1 style={{ fontSize: 24, fontWeight: 800, fontFamily: TOKENS.font.heading, color: dark ? C.darkText : C.text, margin: '0 0 4px' }}>
        Recursos de estudio
      </h1>
      <p style={{ fontSize: 14, color: dark ? C.darkTextSecondary : C.textSecondary, margin: '0 0 8px' }}>
        Recommended sites to improve your Spanish outside class.
      </p>

      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        background: dark ? C.darkSurface : C.primaryLight,
        border: `1px solid ${C.primary}20`, borderRadius: TOKENS.radius.md,
        padding: '10px 16px', marginBottom: 24, fontSize: 13, fontWeight: 600, color: C.primary,
      }}>
        <span style={{ fontSize: 16 }}>◎</span> Tap descriptions to reveal English
      </div>

      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
        gap: 16,
      }}>
        {resources.map((r, i) => (
          <Card key={i} hover style={{ padding: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <div style={{
              height: 4, background: r.color,
              borderRadius: `${TOKENS.radius.lg}px ${TOKENS.radius.lg}px 0 0`,
            }} />
            <div style={{ padding: 22, flex: 1, display: 'flex', flexDirection: 'column' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                <h2 style={{ fontSize: 17, fontWeight: 700, color: dark ? C.darkText : C.text, margin: 0, fontFamily: TOKENS.font.heading }}>{r.name}</h2>
                <Badge color={['primary', 'teal', 'secondary', 'green', 'red'][i % 5]}>{r.skill}</Badge>
              </div>
              <RevealCard spanish={r.descEs} english={r.descEn} style={{ border: 'none', padding: '8px 0', flex: 1 }} />
              <a href={r.url} target="_blank" rel="noopener" style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                color: C.primary, fontSize: 13, fontWeight: 600, textDecoration: 'none', marginTop: 8,
              }}>
                Visit site →
              </a>
            </div>
          </Card>
        ))}
      </div>
    </PageContent>
  );
}

window.NewsPage = NewsPage;
window.HistoryPage = HistoryPage;
window.ResourcesPage = ResourcesPage;
